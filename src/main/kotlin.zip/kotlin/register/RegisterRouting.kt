package com.example.register

import com.example.cache.InMemoryCache
import com.example.cache.User
import com.example.utils.Validators
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import java.util.*

fun Route.RegisterRouting() {
    post("/register") {
        val receive = call.receive<RegisterReceiveRemote>()

        if (!Validators.isValidEmail(receive.email)) {
            call.respond("Email is not valid")
            return@post
        }

        if (InMemoryCache.userList.any { it.login == receive.login }) {
            call.respond("User already exists")
            return@post
        }

        val token = UUID.randomUUID().toString()
        InMemoryCache.userList.add(
            User(
                login = receive.login,
                password = receive.password,
                email = receive.email,
                token = token
            )
        )

        call.respond(RegisterResponseRemote(token = token))
    }
}

package com.example.login

import com.example.cache.InMemoryCache
import com.example.cache.User
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.LoginRouting() {
    post("/login") {
        val receive = call.receive<LoginReceiveRemote>()
        val user = InMemoryCache.userList.firstOrNull { it.login == receive.login }

        if (user == null) {
            call.respond("User not found")
        } else if (user.password == receive.password) {
            call.respond(LoginResponseRemote(token = user.token))
        } else {
            call.respond("Invalid password")
        }
    }
}

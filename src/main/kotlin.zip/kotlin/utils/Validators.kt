package com.example.utils

object Validators {
    fun isValidEmail(email: String): Boolean {
        val emailRegex = Regex("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$")
        return emailRegex.matches(email)
    }
}

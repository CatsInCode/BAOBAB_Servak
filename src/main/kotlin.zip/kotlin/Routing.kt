package com.example.plugins

import com.example.cache.InMemoryCache
import com.example.login.LoginRouting
import com.example.register.RegisterRouting
import io.ktor.server.application.*
import io.ktor.server.routing.*
import io.ktor.server.response.*
import kotlinx.serialization.Serializable

fun Application.configureRouting() {
    routing {
        get("/") {
            call.respond(Test("Hello from Ktor"))
        }
        LoginRouting()
        RegisterRouting()
    }
}

@Serializable
data class Test(val text: String)

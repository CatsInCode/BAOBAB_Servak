package com.example.cache

data class User(val login: String, val password: String, val email: String, val token: String)

object InMemoryCache {
    val userList = mutableListOf<User>()
}
